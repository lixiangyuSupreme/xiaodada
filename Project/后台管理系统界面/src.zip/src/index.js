import React from 'react';
import ReactDOM from 'react-dom';
import 'antd-mobile/dist/antd-mobile.css';
import './add_del_edit.css'

import App from './App';

ReactDOM.render(
  
    <App />,
  
  document.getElementById('root')
);

