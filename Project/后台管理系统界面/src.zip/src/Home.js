import React from 'react';

const Sider = () => {
    return (

      <h1 style={{marginLeft:'350px',marginTop:'-320px'}}>
      Welcome
    </h1>
    );
  
}

export default Sider